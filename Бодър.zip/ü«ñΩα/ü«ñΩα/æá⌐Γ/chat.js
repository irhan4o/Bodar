// Показване/скриване на чатбота
document.getElementById('chatbot-toggle').addEventListener('click', function () {
    const chatbotContainer = document.getElementById('chatbot-container');
    chatbotContainer.style.display = chatbotContainer.style.display === 'none' ? 'block' : 'none';
});
