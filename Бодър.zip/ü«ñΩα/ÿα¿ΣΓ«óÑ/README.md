#  Fliege Mono

![repo cover](cover.png)

Fliege mono It is a free monospaced typeface with a strong personality. It is designed as a monospace font but with a human touch. In order to make the font a bit more playful and less monotonous, the font has ink traps and lowercase ascenders are slightly taller than uppercase cap height.

<!-- download font -->
**[Demo website](https://pavellaptev.github.io/Fliege-mono/)**

**[Download font](https://github.com/PavelLaptev/Fliege-mono/raw/refs/heads/main/font/Fliege-mono.zip)**

---

![font preview](preview.png)
